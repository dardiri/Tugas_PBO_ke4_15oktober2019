﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBoxInput = New System.Windows.Forms.TextBox()
        Me.RadioButtonDecimal_in = New System.Windows.Forms.RadioButton()
        Me.RadioButtonBiner_In = New System.Windows.Forms.RadioButton()
        Me.RadioButtonOktal_in = New System.Windows.Forms.RadioButton()
        Me.RadioButtonHexa_In = New System.Windows.Forms.RadioButton()
        Me.RadioButtonDecimalOut = New System.Windows.Forms.RadioButton()
        Me.RadioButtonBinerOut = New System.Windows.Forms.RadioButton()
        Me.RadioButtonOktalOut = New System.Windows.Forms.RadioButton()
        Me.RadioButtonHexaOut = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBoxOutput = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(320, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kalkulator"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(260, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Nilai 2"
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(318, 19)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(95, 20)
        Me.txt2.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txt3)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.txt1)
        Me.GroupBox1.Controls.Add(Me.txt2)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(723, 139)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Standart"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(460, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Hasil"
        '
        'txt3
        '
        Me.txt3.Location = New System.Drawing.Point(515, 18)
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(95, 20)
        Me.txt3.TabIndex = 7
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(467, 58)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "/"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(376, 58)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "X"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(318, 99)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(91, 23)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "&Reset"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(283, 59)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "-"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(191, 59)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "+"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(127, 22)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(95, 20)
        Me.txt1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(73, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nilai 1"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(335, 180)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "&Reset"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(619, 20)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(81, 23)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "Tutup Aplikasi"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button12)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Controls.Add(Me.Button11)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Button9)
        Me.GroupBox2.Controls.Add(Me.Button10)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 214)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(724, 155)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Ilmiah"
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(470, 71)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(75, 23)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "Log"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(465, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Hasil"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(523, 19)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(95, 20)
        Me.TextBox2.TabIndex = 8
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(335, 121)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 23)
        Me.Button11.TabIndex = 7
        Me.Button11.Text = "&Reset"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(155, 21)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(95, 20)
        Me.TextBox1.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(61, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Masukkan nilai"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(377, 71)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 2
        Me.Button6.Text = "tan"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(188, 71)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "sin"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(281, 71)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 23)
        Me.Button10.TabIndex = 0
        Me.Button10.Text = "cos"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(335, 139)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(75, 23)
        Me.Button14.TabIndex = 0
        Me.Button14.Text = "Konversi"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(118, 25)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Masukkan nilai"
        '
        'TextBoxInput
        '
        Me.TextBoxInput.Location = New System.Drawing.Point(213, 25)
        Me.TextBoxInput.Name = "TextBoxInput"
        Me.TextBoxInput.Size = New System.Drawing.Size(95, 20)
        Me.TextBoxInput.TabIndex = 5
        '
        'RadioButtonDecimal_in
        '
        Me.RadioButtonDecimal_in.AutoSize = True
        Me.RadioButtonDecimal_in.Location = New System.Drawing.Point(24, 16)
        Me.RadioButtonDecimal_in.Name = "RadioButtonDecimal_in"
        Me.RadioButtonDecimal_in.Size = New System.Drawing.Size(62, 17)
        Me.RadioButtonDecimal_in.TabIndex = 10
        Me.RadioButtonDecimal_in.TabStop = True
        Me.RadioButtonDecimal_in.Text = "Desimal"
        Me.RadioButtonDecimal_in.UseVisualStyleBackColor = True
        '
        'RadioButtonBiner_In
        '
        Me.RadioButtonBiner_In.AutoSize = True
        Me.RadioButtonBiner_In.Location = New System.Drawing.Point(24, 40)
        Me.RadioButtonBiner_In.Name = "RadioButtonBiner_In"
        Me.RadioButtonBiner_In.Size = New System.Drawing.Size(55, 17)
        Me.RadioButtonBiner_In.TabIndex = 11
        Me.RadioButtonBiner_In.TabStop = True
        Me.RadioButtonBiner_In.Text = "Binner"
        Me.RadioButtonBiner_In.UseVisualStyleBackColor = True
        '
        'RadioButtonOktal_in
        '
        Me.RadioButtonOktal_in.AutoSize = True
        Me.RadioButtonOktal_in.Location = New System.Drawing.Point(97, 19)
        Me.RadioButtonOktal_in.Name = "RadioButtonOktal_in"
        Me.RadioButtonOktal_in.Size = New System.Drawing.Size(50, 17)
        Me.RadioButtonOktal_in.TabIndex = 12
        Me.RadioButtonOktal_in.TabStop = True
        Me.RadioButtonOktal_in.Text = "Oktal"
        Me.RadioButtonOktal_in.UseVisualStyleBackColor = True
        '
        'RadioButtonHexa_In
        '
        Me.RadioButtonHexa_In.AutoSize = True
        Me.RadioButtonHexa_In.Location = New System.Drawing.Point(97, 42)
        Me.RadioButtonHexa_In.Name = "RadioButtonHexa_In"
        Me.RadioButtonHexa_In.Size = New System.Drawing.Size(90, 17)
        Me.RadioButtonHexa_In.TabIndex = 13
        Me.RadioButtonHexa_In.TabStop = True
        Me.RadioButtonHexa_In.Text = "Hexa Desimal"
        Me.RadioButtonHexa_In.UseVisualStyleBackColor = True
        '
        'RadioButtonDecimalOut
        '
        Me.RadioButtonDecimalOut.AutoSize = True
        Me.RadioButtonDecimalOut.Location = New System.Drawing.Point(23, 14)
        Me.RadioButtonDecimalOut.Name = "RadioButtonDecimalOut"
        Me.RadioButtonDecimalOut.Size = New System.Drawing.Size(62, 17)
        Me.RadioButtonDecimalOut.TabIndex = 14
        Me.RadioButtonDecimalOut.TabStop = True
        Me.RadioButtonDecimalOut.Text = "Desimal"
        Me.RadioButtonDecimalOut.UseVisualStyleBackColor = True
        '
        'RadioButtonBinerOut
        '
        Me.RadioButtonBinerOut.AutoSize = True
        Me.RadioButtonBinerOut.Location = New System.Drawing.Point(23, 38)
        Me.RadioButtonBinerOut.Name = "RadioButtonBinerOut"
        Me.RadioButtonBinerOut.Size = New System.Drawing.Size(55, 17)
        Me.RadioButtonBinerOut.TabIndex = 15
        Me.RadioButtonBinerOut.TabStop = True
        Me.RadioButtonBinerOut.Text = "Binner"
        Me.RadioButtonBinerOut.UseVisualStyleBackColor = True
        '
        'RadioButtonOktalOut
        '
        Me.RadioButtonOktalOut.AutoSize = True
        Me.RadioButtonOktalOut.Location = New System.Drawing.Point(91, 16)
        Me.RadioButtonOktalOut.Name = "RadioButtonOktalOut"
        Me.RadioButtonOktalOut.Size = New System.Drawing.Size(50, 17)
        Me.RadioButtonOktalOut.TabIndex = 16
        Me.RadioButtonOktalOut.TabStop = True
        Me.RadioButtonOktalOut.Text = "Oktal"
        Me.RadioButtonOktalOut.UseVisualStyleBackColor = True
        '
        'RadioButtonHexaOut
        '
        Me.RadioButtonHexaOut.AutoSize = True
        Me.RadioButtonHexaOut.Location = New System.Drawing.Point(91, 39)
        Me.RadioButtonHexaOut.Name = "RadioButtonHexaOut"
        Me.RadioButtonHexaOut.Size = New System.Drawing.Size(90, 17)
        Me.RadioButtonHexaOut.TabIndex = 17
        Me.RadioButtonHexaOut.TabStop = True
        Me.RadioButtonHexaOut.Text = "Hexa Desimal"
        Me.RadioButtonHexaOut.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(364, 77)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(19, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "ke"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.TextBoxOutput)
        Me.GroupBox3.Controls.Add(Me.GroupBox5)
        Me.GroupBox3.Controls.Add(Me.Button7)
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.TextBoxInput)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Button14)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 376)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(724, 233)
        Me.GroupBox3.TabIndex = 9
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Programmer"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(416, 28)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(30, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Hasil"
        '
        'TextBoxOutput
        '
        Me.TextBoxOutput.Location = New System.Drawing.Point(452, 25)
        Me.TextBoxOutput.Name = "TextBoxOutput"
        Me.TextBoxOutput.Size = New System.Drawing.Size(95, 20)
        Me.TextBoxOutput.TabIndex = 21
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.RadioButtonDecimalOut)
        Me.GroupBox5.Controls.Add(Me.RadioButtonBinerOut)
        Me.GroupBox5.Controls.Add(Me.RadioButtonOktalOut)
        Me.GroupBox5.Controls.Add(Me.RadioButtonHexaOut)
        Me.GroupBox5.Location = New System.Drawing.Point(418, 54)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(203, 70)
        Me.GroupBox5.TabIndex = 20
        Me.GroupBox5.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.RadioButtonDecimal_in)
        Me.GroupBox4.Controls.Add(Me.RadioButtonBiner_In)
        Me.GroupBox4.Controls.Add(Me.RadioButtonOktal_in)
        Me.GroupBox4.Controls.Add(Me.RadioButtonHexa_In)
        Me.GroupBox4.Location = New System.Drawing.Point(121, 54)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(208, 70)
        Me.GroupBox4.TabIndex = 19
        Me.GroupBox4.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Red
        Me.ClientSize = New System.Drawing.Size(748, 610)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Kalkulator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents txt1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button11 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Button14 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBoxInput As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents RadioButtonDecimal_in As RadioButton
    Friend WithEvents RadioButtonBiner_In As RadioButton
    Friend WithEvents RadioButtonOktal_in As RadioButton
    Friend WithEvents RadioButtonHexa_In As RadioButton
    Friend WithEvents RadioButtonDecimalOut As RadioButton
    Friend WithEvents RadioButtonBinerOut As RadioButton
    Friend WithEvents RadioButtonOktalOut As RadioButton
    Friend WithEvents RadioButtonHexaOut As RadioButton
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TextBoxOutput As TextBox
    Friend WithEvents txt3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button12 As System.Windows.Forms.Button
End Class
