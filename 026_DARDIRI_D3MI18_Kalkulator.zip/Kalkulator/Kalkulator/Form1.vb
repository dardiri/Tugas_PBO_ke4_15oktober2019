﻿Option Explicit On
Public Class Form1

    Const phi As Double = 22 / 7
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TextBoxInput.Text = ""
        TextBoxOutput.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        txt3.Text = Val(txt1.Text) + Val(txt2.Text)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        txt3.Text = Val(txt1.Text) - Val(txt2.Text)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        txt3.Text = Val(txt1.Text) * Val(txt2.Text)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        txt3.Text = Val(txt1.Text) / Val(txt2.Text)
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim keluar As MsgBoxResult
        keluar = MsgBox("Apakah Akan Keluar??..", MsgBoxStyle.YesNo, "Warning Force Close")
        If keluar = MsgBoxResult.Yes Then
            Close()
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        TextBox2.Text = Math.Sin(TextBox1.Text * (phi / 180))
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        TextBox2.Text = Math.Cos(TextBox1.Text * (phi / 180))
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBox2.Text = Math.Tan(TextBox1.Text * (phi / 180))
    End Sub

    Private Sub Button12_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button12.Click
        TextBox2.Text = Math.Log(TextBox1.Text)
    End Sub


    Public Function BinToDes(ByVal NBiner As String) As Long
        Dim A As Integer
        Dim B As Long
        Dim Nilai As Long
        On Error GoTo ErrorHandler
        B = 1
        For A = Len(NBiner) To 1 Step -1
            If Mid(NBiner, A, 1) = "1" Then Nilai = Nilai + B
            B = B * 2
        Next
        BinToDes = Nilai
        Exit Function
ErrorHandler:
        BinToDes = 0
    End Function
    Public Function DesToBin(ByVal NDesimal As Long) As String
        Dim C As Byte
        Dim D As Long
        Dim Nilai As Integer
        On Error GoTo ErrorHandler
        D = (2 ^ 31) - 1
        While D > 0
            If NDesimal - D >= 0 Then
                NDesimal = NDesimal - D
                Nilai = Nilai & "1"
            Else
                If Val(Nilai) > 0 Then Nilai = Nilai & "0"
            End If
            D = D / 2
        End While
        DesToBin = Nilai
        Exit Function
ErrorHandler:
        DesToBin = 0
    End Function
    Public Function DesToHex(ByVal NDesimal As Long) As String
        DesToHex = Hex(NDesimal)
    End Function

    Public Function HexToDes(ByVal NHexa As String) As Long
        Dim E As Integer
        Dim Nilai As Long
        Dim F As Long
        Dim CharNilai As Byte
        On Error GoTo ErrorHandler
        For E = Len(NHexa) To 1 Step -1
            Select Case Mid(NHexa, E, 1)
                Case "0" To "9" : CharNilai = CInt(Mid(NHexa, E, 1))
                Case Else : CharNilai = Asc(Mid(NHexa, E, 1)) - 55
            End Select
            Nilai = Nilai + ((16 ^ F) * CharNilai)
            F = F + 1
        Next E
        HexToDes = Nilai
        Exit Function
ErrorHandler:
        HexToDes = 0
    End Function
    Public Function DesToOk(ByVal NDesimal As Long) As String
        DesToOk = Oct(NDesimal)
    End Function
    Public Function OkToDes(ByVal NOktal As String) As Long
        Dim G As Integer
        Dim H As Long
        Dim Nilai As Long
        On Error GoTo ErrorHandler
        For G = Len(NOktal) To 1 Step -1
            Nilai = Nilai + (8 ^ H) * CInt(Mid(NOktal, G, 1))
            H = H + 1
        Next G
        OkToDes = Nilai
        Exit Function
ErrorHandler:
        OkToDes = 0
    End Function
    Public Function BinToOk(ByVal bin As Long) As String
        BinToOk = DesToOk(BinToDes(bin))
    End Function

    Public Function OkToBin(ByVal NOktal As Double) As String
        OkToBin = DesToBin(OkToDes(NOktal))
    End Function
    Public Function BinToHex(ByVal NBiner As Long) As String
        BinToHex = DesToHex(BinToDes(NBiner))
    End Function

    Public Function OkToHex(ByVal NOktal As Double) As String
        OkToHex = DesToHex(OkToDes(NOktal))
    End Function

    Public Function HexToBin(ByVal NHexa As String) As String
        HexToBin = DesToBin(HexToDes(NHexa))
    End Function
    Public Function HexToOk(ByVal NHexa As String) As Double
        HexToOk = DesToOk(HexToDes(NHexa))
    End Function

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        If RadioButtonBiner_In.Checked And RadioButtonDecimalOut.Checked Then TextBoxOutput.Text = BinToDes(TextBoxInput.Text)
        If RadioButtonBiner_In.Checked And RadioButtonBinerOut.Checked Then TextBoxOutput.Text = TextBoxInput.Text
        If RadioButtonBiner_In.Checked And RadioButtonOktalOut.Checked Then TextBoxOutput.Text = BinToOk(TextBoxInput.Text)
        If RadioButtonBiner_In.Checked And RadioButtonHexaOut.Checked Then TextBoxOutput.Text = BinToHex(TextBoxInput.Text)
        If RadioButtonDecimal_in.Checked And RadioButtonBinerOut.Checked Then TextBoxOutput.Text = DesToBin(TextBoxInput.Text)
        If RadioButtonDecimal_in.Checked And RadioButtonDecimalOut.Checked Then TextBoxOutput.Text = TextBoxInput.Text
        If RadioButtonDecimal_in.Checked And RadioButtonOktalOut.Checked Then TextBoxOutput.Text = DesToOk(TextBoxInput.Text)
        If RadioButtonDecimal_in.Checked And RadioButtonHexaOut.Checked Then TextBoxOutput.Text = DesToHex(TextBoxInput.Text)
        If RadioButtonOktal_in.Checked And RadioButtonBinerOut.Checked Then TextBoxOutput.Text = OkToBin(TextBoxInput.Text)
        If RadioButtonOktal_in.Checked And RadioButtonHexaOut.Checked Then TextBoxOutput.Text = OkToHex(TextBoxInput.Text)
        If RadioButtonOktal_in.Checked And RadioButtonDecimalOut.Checked Then TextBoxOutput.Text = OkToDes(TextBoxInput.Text)
        If RadioButtonOktal_in.Checked And RadioButtonOktalOut.Checked Then TextBoxOutput.Text = TextBoxInput.Text
        If RadioButtonHexa_In.Checked And RadioButtonBinerOut.Checked Then TextBoxOutput.Text = HexToBin(TextBoxInput.Text)
        If RadioButtonHexa_In.Checked And RadioButtonDecimalOut.Checked Then TextBoxOutput.Text = HexToDes(TextBoxInput.Text)
        If RadioButtonHexa_In.Checked And RadioButtonOktalOut.Checked Then TextBoxOutput.Text = HexToOk(TextBoxInput.Text)
        If RadioButtonHexa_In.Checked And RadioButtonHexaOut.Checked Then TextBoxOutput.Text = TextBoxInput.Text
        If TextBoxInput.Text = "" Then
            MsgBox("maaf ???? anda belum memasukan bilangan")
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBoxOutput.Enabled = False
        TextBox2.Enabled = False
        txt3.Enabled = False
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        txt1.Text = ""
        txt2.Text = ""
        txt3.Text = ""
    End Sub


End Class
